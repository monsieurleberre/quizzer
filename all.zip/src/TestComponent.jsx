import React from 'react'

class TestComponent extends React.Component {
  render() {
    return (
      <h1>Hello, world.</h1>
    );
  }
}
