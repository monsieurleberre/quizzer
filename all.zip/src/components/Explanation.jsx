import React from 'react'

class Explanation extends React.Component {
    constructor() {
        super();
        this.state = {

        };
        this.props = {

        };
    }

    render() {
        return (
            <div className="explanation">
                {this.state.explanation}
            </div>
        )
    }
}