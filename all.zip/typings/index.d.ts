/// <reference path="globals/babel-core/index.d.ts" />
/// <reference path="globals/webpack/index.d.ts" />
